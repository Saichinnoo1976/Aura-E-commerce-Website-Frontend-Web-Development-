import React from "react";
import { assets } from "../assets/assets";
const Navbar = ({ setToken }) => {
  return (
    <div className="flex items-center py-2 px-[4%] justify-between">
      <img
        src={assets.logospacesai}
        alt="logo"
        style={{ width: "180px", height: "auto" }}
      />
      <button
        onClick={() => setToken("")}
        className="bg-[#ff4c4c] text-white text-sm my-8 px-8 py-3"
      >
        Logout
      </button>
    </div>
  );
};

export default Navbar;
