import React from 'react'

const Orders = () => {
  return (
    <div></div>
  )
}

export default Orders