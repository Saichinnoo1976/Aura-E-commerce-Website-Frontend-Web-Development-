import React from 'react'

const Add = () => {
  return (
    <div>Add</div>
  )
}

export default Add